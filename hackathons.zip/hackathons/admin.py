from django.contrib import admin
from . import models
# Register your models here.

admin.site.register(models.Hackathon)
admin.site.register(models.Fest)
admin.site.register(models.Esummit)
admin.site.register(models.teammatesearch)
admin.site.register(models.team_requests)
admin.site.register(models.userid_githubuser)
